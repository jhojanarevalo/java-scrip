function vista_miniatura(ruta){
    document.getElementById("visor_great").src=ruta
}