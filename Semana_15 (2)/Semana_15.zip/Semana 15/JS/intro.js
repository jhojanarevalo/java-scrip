function saludo(nombre){
    alert("Hola…"+nombre +"\n" + "Vamos aprender los 5 programas fantásticos:"+"\n"+"HTML- CSS- JS - PHP-MYSQL");  
}